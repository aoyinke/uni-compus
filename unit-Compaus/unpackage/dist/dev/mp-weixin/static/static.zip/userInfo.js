userInfo: {
					userName: "天堂屠夫",
					hometown: "江苏省-常州市-天宁区",
					job: "学生",
					loveState: "恋爱中",
					userSex: "男",
					avatar: "static/test/avatar.png",
					userBirthday: "2000-8-28"，
					personalDetail: {
					avatar: '../../static/test/timg.jpg',
					good: "11k",
					like: "11",
					follower: "12",
					userBg: '../../static/test/1.jpg',
					userName: "天堂屠夫",
					userId:"1351058003"
				},
				}