{
							groupName: "轻松一校项目组",
							groupLogo: "../../static/test/avatar.png",
							intro: "轻松一校项目组是地球上最强大的组织之一，它负责..."
						}