newsList: [{
					content: [{
						grouplogo: "../static/test/avatar.png",
						groupName: "比赛大佬组",
						activityStartTime: "17小时前",
						activityPropagate: {
							type: "img",
							src: ['../static/test/1.jpg', '../static/test/timg.jpg', '../static/test/3.png']
						},
						hotNum: 80,
						commentNum: 6,
						commentDetail: [{
							commentor: "天堂屠夫",
							commentContent: "nb....."
						},
						{
							commentor: "天堂屠夫",
							commentContent: "tnb....."
						},
						{
							commentor: "天堂屠夫",
							commentContent: "cznb....."
						}]
					},
					{
						grouplogo: "../static/test/avatar.png",
						groupName: "比赛大佬组",
						activityStartTime: "17小时前",
						activityPropagate: {
							type: "img",
							src: ['../static/test/1.jpg', '../static/test/timg.jpg', '../static/test/3.png']
						},
						hotNum: 80,
						commentNum: 6,
						commentDetail: [{
							commentor: "天堂屠夫",
							commentContent: "nb....."
						},
						{
							commentor: "天堂屠夫",
							commentContent: "tnb....."
						},
						{
							commentor: "天堂屠夫",
							commentContent: "cznb....."
						}]
					},
					{
						grouplogo: "../static/test/avatar.png",
						groupName: "比赛大佬组",
						activityStartTime: "17小时前",
						activityPropagate: {
							type: "img",
							src: ['../static/test/1.jpg', '../static/test/timg.jpg', '../static/test/3.png']
						},
						hotNum: 80,
						commentNum: 6,
						commentDetail: [{
							commentor: "天堂屠夫",
							commentContent: "nb....."
						},
						{
							commentor: "天堂屠夫",
							commentContent: "tnb....."
						},
						{
							commentor: "天堂屠夫",
							commentContent: "cznb....."
						}]
					}],
				},
				{
					content: [{
						grouplogo: "../../static/test/avatar.png",
						groupName: "比赛大佬组",
						activityStartTime: "17小时前",
						activityPropagate: {
							type: "img",
							src: ['../static/test/1.jpg', '../static/test/timg.jpg', '../static/test/3.png']
						},
						hotNum: 80,
						commentNum: 6,
						commentDetail: [{
							commentor: "天堂屠夫",
							commentContent: "nb....."
						},
						{
							commentor: "天堂屠夫",
							commentContent: "tnb....."
						},
						{
							commentor: "天堂屠夫",
							commentContent: "cznb....."
						}]
					}],
				}],