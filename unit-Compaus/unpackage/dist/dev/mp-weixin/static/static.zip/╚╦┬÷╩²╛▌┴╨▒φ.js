peopleList: [{
					src: "../static/test/waterfull/1.jpg",
					introduction: "来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊",
					loveNum:0,
					tag:['nb','无与伦比','技术宅'],
					groupName:"轻松一校"
				}, {
					src: "../static/test/waterfull/2.jpg",
					groupName:"轻松一校",
					introduction: "来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊",
					loveNum:0
				}, {
					src: "../static/test/waterfull/3.jpg",
					groupName:"轻松一校",
					introduction: "来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊",
					loveNum:0
				}, {
					src: "../static/test/waterfull/4.jpg",
					groupName:"轻松一校",
					introduction: "来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊",
					loveNum:0
				}, {
					src: "../static/test/waterfull/5.jpg",
					groupName:"轻松一校",
					introduction: "来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊",
					loveNum:0
				}, {
					src: "../static/test/waterfull/6.jpg",
					groupName:"轻松一校",
					introduction: "来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊",
					loveNum:0
				}, {
					src: "../static/test/waterfull/7.jpg",
					groupName:"轻松一校",
					introduction: "来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊",
					loveNum:0
				}, {
					src: "../static/test/waterfull/8.jpg",
					groupName:"轻松一校",
					introduction: "来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊",
					loveNum:0
				}, {
					src: "../static/test/waterfull/9.jpg",
					groupName:"轻松一校",
					introduction: "来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊",
					loveNum:0
				}, {
					src: "../static/test/waterfull/10.jpg",
					groupName:"轻松一校",
					introduction: "来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊",
					loveNum:0
				}, {
					src: "../static/test/waterfull/11.jpg",
					groupName:"轻松一校",
					introduction: "来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊",
					loveNum:0
				}, {
					src: "../static/test/waterfull/12.jpg",
					groupName:"轻松一校",
					introduction: "来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊来见识我的瀑布流啊",
					loveNum:0
				}]