activityDetail: {
					groupName: '轻松一校',
					activityStartTime: "17小时前",
					groupLogo: '../static/test/avatar.png',
					text:'岁月无情',
					imgs:['../../static/test/waterfull/1.jpg','../../static/test/waterfull/2.jpg','../../static/test/waterfull/3.jpg']
				}